#include <pspgu.h>
#include <pspgum.h>
#include <pspdebug.h>
#include <pspdisplay.h>
#include <math.h>
#include "game.h"
#include "effects.h"

typedef struct{unsigned int color;float x,y,z;} V;
static unsigned int __attribute__((aligned(16))) list[262144];
void render_init(void){sceGuInit();sceGuStart(GU_DIRECT,list);sceGuDrawBuffer(GU_PSM_8888,(void*)0,512);sceGuDispBuffer(480,272,(void*)0x88000,512);sceGuDepthBuffer((void*)0x110000,512);sceGuOffset(1808,1912);sceGuViewport(2048,2048,480,272);sceGuDepthRange(65535,0);sceGuScissor(0,0,480,272);sceGuEnable(GU_SCISSOR_TEST);sceGuDepthFunc(GU_GEQUAL);sceGuFrontFace(GU_CW);sceGuShadeModel(GU_SMOOTH);sceGuFinish();sceGuSync(0,0);sceDisplayWaitVblankStart();sceGuDisplay(GU_TRUE);}

static void box(float x,float y,float z,float sx,float sy,float sz,unsigned int c){
 sceGumPushMatrix();ScePspFVector3 p={x,y,z},s={sx,sy,sz};sceGumTranslate(&p);sceGumScale(&s);
 V v[8]={{c,-1,-1,-1},{c,1,-1,-1},{c,1,1,-1},{c,-1,1,-1},{c,-1,-1,1},{c,1,-1,1},{c,1,1,1},{c,-1,1,1}};
 unsigned short ix[]={0,1,2,0,2,3,4,6,5,4,7,6,0,4,5,0,5,1,3,2,6,3,6,7,0,3,7,0,7,4,1,5,6,1,6,2};
 sceGumDrawArray(GU_TRIANGLES,GU_COLOR_8888|GU_VERTEX_32BITF|GU_TRANSFORM_3D,36,ix,v);sceGumPopMatrix();
}
static void camera(const GameState*g){
 sceGumMatrixMode(GU_VIEW);sceGumLoadIdentity();
 ScePspFVector3 e={g->player.pos.x,g->player.pos.y+5,g->player.pos.z+9};
 ScePspFVector3 a={g->player.pos.x,g->player.pos.y+1,g->player.pos.z},u={0,1,0};
 sceGumLookAt(&e,&a,&u);sceGumMatrixMode(GU_MODEL);sceGumLoadIdentity();
}
static void part(float x,float y,float z,float sx,float sy,float sz,float rz,unsigned int c){sceGumPushMatrix();ScePspFVector3 p={x,y,z},s={sx,sy,sz};sceGumTranslate(&p);sceGumRotateZ(rz);sceGumScale(&s);V v[8]={{c,-1,-1,-1},{c,1,-1,-1},{c,1,1,-1},{c,-1,1,-1},{c,-1,-1,1},{c,1,-1,1},{c,1,1,1},{c,-1,1,1}};unsigned short ix[]={0,1,2,0,2,3,4,6,5,4,7,6,0,4,5,0,5,1,3,2,6,3,6,7,0,3,7,0,7,4,1,5,6,1,6,2};sceGumDrawArray(GU_TRIANGLES,GU_COLOR_8888|GU_VERTEX_32BITF|GU_TRANSFORM_3D,36,ix,v);sceGumPopMatrix();}
static void shinobi(Vec3 p,float yaw,float t,int state,unsigned int cloth,int boss){float stride=state==1?sinf(t)*.65f:0,slash=state>=2?sinf(t*1.7f)*1.15f:0,sc=boss?1.65f:1;ScePspFVector3 q={p.x,p.y,p.z},s={sc,sc,sc};sceGumPushMatrix();sceGumTranslate(&q);sceGumRotateY(yaw);sceGumScale(&s);part(0,1.25f,0,.48f,.62f,.3f,0,cloth);part(0,2.12f,0,.35f,.34f,.34f,0,0xFFD39C76);part(-.24f,.46f,0,.18f,.52f,.2f,stride,0xFF20232B);part(.24f,.46f,0,.18f,.52f,.2f,-stride,0xFF20232B);part(-.62f,1.35f,0,.15f,.55f,.16f,-stride*.7f,cloth);part(.62f,1.35f,0,.15f,.55f,.16f,stride*.7f-slash,cloth);part(.88f,1.12f,0,.06f,.72f,.07f,-.55f-slash,0xFFC8D8E8);part(0,2.12f,.34f,.42f,.09f,.05f,0,0xFF20232B);sceGumPopMatrix();}
void game_render(const GameState*g){
 sceGuStart(GU_DIRECT,list);sceGuClearColor(0xFF10131D);sceGuClear(GU_COLOR_BUFFER_BIT|GU_DEPTH_BUFFER_BIT);
 sceGuEnable(GU_DEPTH_TEST);
 sceGumMatrixMode(GU_PROJECTION);sceGumLoadIdentity();sceGumPerspective(55,480.0f/272,0.5f,1000);camera(g);
 box(0,-.35f,2,15,.35f,15,0xFF353744);
 shinobi(g->player.pos,g->player.yaw,g->player.animTime,g->player.animState,0xFF253C91,0);
 for(int i=0;i<MAX_ENEMIES;i++){const Enemy*e=&g->enemies[i];if(!e->alive)continue;
  unsigned int c=e->elite?0xFFB06018:0xFF7A2937;
  if(e->stagger)c=0xFFFFFFFF;
  shinobi(e->pos,e->yaw,g->frame*.08f,e->stagger?2:1,c,0);
 }
 if(g->boss.active)shinobi(g->boss.pos,g->boss.yaw,g->boss.animTime,g->boss.stagger?2:1,g->boss.phase==2?0xFF722090:0xFF3030A0,1);
 effects_render();
 sceGuDisable(GU_DEPTH_TEST);
 sceGuFinish();sceGuSync(0,0);
 /* Debug HUD text: visible on real PSP screen */
 pspDebugScreenSetXY(1,1);
 pspDebugScreenPrintf("RISE OF A SHINOBI  LV %d  WAVE %d\n",g->player.level,g->wave);
 pspDebugScreenPrintf("HP %d/%d  CHAKRA %d/%d  XP %d  SP %d\n",
  g->player.hp,g->player.maxHp,g->player.chakra,g->player.maxChakra,g->player.xp,g->player.skillPoints);
 pspDebugScreenPrintf("SQUARE COMBO  TRIANGLE HEAVY  CROSS DASH  L LOCK\n");
 pspDebugScreenPrintf("UP/RIGHT/DOWN TECHNIQUES   CIRCLE SKILL   START PAUSE");
 if(g->boss.active)pspDebugScreenPrintf("\nBOSS: THE VEILED WARLORD %d/%d PHASE %d",g->boss.hp,g->boss.maxHp,g->boss.phase);if(g->paused)pspDebugScreenPrintf("\nPAUSED");
}
