#include <pspgu.h>
#include <pspgum.h>
#include <math.h>
#include "effects.h"
static Effect fx[MAX_EFFECTS];
typedef struct{unsigned int color;float x,y,z;} V;
void effects_init(void){for(int i=0;i<MAX_EFFECTS;i++)fx[i].active=0;}
void effects_spawn(Vec3 p,int type,float scale){
 for(int i=0;i<MAX_EFFECTS;i++)if(!fx[i].active){fx[i]=(Effect){p,.36f,.36f,scale,type,1};break;}
}
void effects_update(float dt){for(int i=0;i<MAX_EFFECTS;i++)if(fx[i].active){fx[i].life-=dt;fx[i].scale+=dt*2;if(fx[i].life<=0)fx[i].active=0;}}
static void flash(const Effect*e){
 float t=1-e->life/e->maxLife,s=e->scale*(.35f+t);unsigned int cs[]={0xFFFFD060,0xFF40E8FF,0xFFC050FF,0xFFFFFFFF},c=cs[e->type&3];
 V v[4]={{c,-s,0,0},{c,s,0,0},{c,s,1.5f*s,0},{c,-s,1.5f*s,0}};
 unsigned short ix[]={0,1,2,0,2,3};
 sceGumPushMatrix();ScePspFVector3 p={e->pos.x,e->pos.y,e->pos.z};sceGumTranslate(&p);
 sceGumDrawArray(GU_TRIANGLES,GU_COLOR_8888|GU_VERTEX_32BITF|GU_TRANSFORM_3D,6,ix,v);
 sceGumPopMatrix();
}
void effects_render(void){
 sceGuEnable(GU_BLEND);sceGuBlendFunc(GU_ADD,GU_SRC_ALPHA,GU_ONE_MINUS_SRC_ALPHA,0,0);
 for(int i=0;i<MAX_EFFECTS;i++)if(fx[i].active)flash(&fx[i]);
 sceGuDisable(GU_BLEND);
}
