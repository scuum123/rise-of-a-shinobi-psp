# The Rise of a Shinobi — PSP Prototype v4

This iteration adds animated in-game shinobi, working combat effects, and the two-phase Veiled Warlord boss every fifth wave. All characters, techniques, and assets are original.

### Added
- Original low-poly shinobi model assets (OBJ)
- Original blade and kunai assets
- Visual-art direction document
- Effect system foundation for sword/jutsu flashes
- Effect spawning/update/render hooks
- Expanded original character and technique plan

### Important
The project is intentionally built around original characters and assets. It can have an anime ninja aesthetic inspired by the era without reproducing Naruto characters, logos, music, artwork, or ripped game assets.

### PSP build
Use a configured PSPSDK/devkitPro environment:

```sh
make
```

Install to:

`PSP/GAME/RiseShinobi/EBOOT.PBP`
