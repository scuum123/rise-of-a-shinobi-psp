#include <math.h>
#include "game.h"
float dist2(Vec3 a,Vec3 b){float x=a.x-b.x,z=a.z-b.z;return x*x+z*z;}
float clampf(float x,float a,float b){return x<a?a:x>b?b:x;}
float length2(float x,float z){return sqrtf(x*x+z*z);}
