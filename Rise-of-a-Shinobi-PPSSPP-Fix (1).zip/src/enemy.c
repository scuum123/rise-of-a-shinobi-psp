#include <math.h>
#include "game.h"
#include "effects.h"
extern float dist2(Vec3,Vec3);

static void spawn(GameState*g){
 if(g->wave%5==0){for(int i=0;i<MAX_ENEMIES;i++)g->enemies[i].alive=0;g->boss=(Boss){{0,0,8},650+g->wave*70,650+g->wave*70,1,1,90,0,0,0};g->enemiesRemaining=1;return;}g->boss.active=0;
 int n=5+g->wave*2;if(n>MAX_ENEMIES)n=MAX_ENEMIES;
 for(int i=0;i<n;i++){
  Enemy*e=&g->enemies[i];e->alive=1;e->elite=(g->wave>=3&&i==0);
  e->maxHp=e->hp=(e->elite?220:70)+g->wave*16;
  e->pos.x=((i%4)-1.5f)*3.0f;e->pos.z=((i/4)-1)*3.0f+6;
  e->stagger=0;e->attackCooldown=25+i*2;
 }
 g->enemiesRemaining=n;
}
void enemy_init(GameState*g){g->wave=1;spawn(g);}
void enemy_update(GameState*g){
 int alive=0;
 if(g->boss.active){Boss*b=&g->boss;alive=1;b->animTime+=.06f;if(b->stagger)b->stagger--;else{float dx=g->player.pos.x-b->pos.x,dz=g->player.pos.z-b->pos.z,d=sqrtf(dx*dx+dz*dz);b->yaw=atan2f(dx,dz);b->phase=b->hp<b->maxHp/2?2:1;if(d>3.2f){float sp=b->phase==2?.075f:.052f;b->pos.x+=dx/(d+.01f)*sp;b->pos.z+=dz/(d+.01f)*sp;}else if(b->attackTimer<=0){if(!g->player.invincibleTimer)g->player.hp-=b->phase==2?35:24;effects_spawn(g->player.pos,FX_SHADOW_BURST,1.2f);b->attackTimer=b->phase==2?42:65;}else b->attackTimer--;}}
 for(int i=0;i<MAX_ENEMIES;i++){
  Enemy*e=&g->enemies[i];if(!e->alive)continue;alive++;
  if(e->stagger){e->stagger--;continue;}
  float dx=g->player.pos.x-e->pos.x,dz=g->player.pos.z-e->pos.z;
  float d=sqrtf(dx*dx+dz*dz);
  e->yaw=atan2f(dx,dz);
  if(d>2){e->pos.x+=dx/(d+.01f)*.045f;e->pos.z+=dz/(d+.01f)*.045f;}
  else if(e->attackCooldown<=0){
   if(!g->player.invincibleTimer)g->player.hp-=e->elite?18:8;
   e->attackCooldown=e->elite?30:45;
  }else e->attackCooldown--;
 }
 g->enemiesRemaining=alive;
 if(!alive){g->wave++;spawn(g);}
}
