#include <math.h>
#include "game.h"
#include "effects.h"
extern float dist2(Vec3,Vec3);
void skill_unlock(Player*);

static void hit_area(GameState*g,float range,int damage,int knock){
 Player*p=&g->player;
 for(int i=0;i<MAX_ENEMIES;i++){
  Enemy*e=&g->enemies[i]; if(!e->alive)continue;
  if(dist2(p->pos,e->pos)<=range*range){
   e->hp-=damage;e->stagger=knock;effects_spawn(e->pos,FX_HIT,.45f);
   if(e->hp<=0){e->alive=0;p->xp+=e->elite?120:40;}
  }
 }
 if(g->boss.active&&dist2(p->pos,g->boss.pos)<=range*range){g->boss.hp-=damage;g->boss.stagger=knock/2;effects_spawn(g->boss.pos,FX_HIT,.8f);if(g->boss.hp<=0){g->boss.active=0;p->xp+=500;p->skillPoints++;}}
}
static void technique(GameState*g,int id){
 Player*p=&g->player;if(p->techniqueTimer)return;
 int cost=25+(id*5); if(p->chakra<cost)return;
 p->chakra-=cost;p->techniqueTimer=28;
 effects_spawn(p->pos,id==2?FX_SHADOW_BURST:FX_CHAKRA_RING,1.4f+id*.35f);
 if(id==0)hit_area(g,5.5f,55,18);
 if(id==1)hit_area(g,7.0f,75,25);
 if(id==2){p->invincibleTimer=45;hit_area(g,3.5f,100,35);}
}
void player_update(GameState*g,const SceCtrlData*b){
 Player*p=&g->player;
 float x=(b->Lx-128)/128.0f,z=(b->Ly-128)/128.0f;
 float mag=sqrtf(x*x+z*z);if(mag>1){x/=mag;z/=mag;}
 float speed=(b->Buttons&PSP_CTRL_RTRIGGER)?.18f:.10f;
 if(p->dashTimer){p->dashTimer--;speed=.28f;}
 p->pos.x+=x*speed;p->pos.z+=z*speed;
 if(mag>.15f){p->yaw=atan2f(x,z);p->animState=1;}else p->animState=0;p->animTime+=.0166667f*(p->animState?7:2);
 if(p->attackTimer)p->attackTimer--;
 if(p->techniqueTimer)p->techniqueTimer--;
 if(p->invincibleTimer)p->invincibleTimer--;
 if(p->chakra<p->maxChakra)p->chakra++;
 if((b->Buttons&PSP_CTRL_LTRIGGER)&&p->target<0){
  float best=999999;int bi=-1;
  for(int i=0;i<MAX_ENEMIES;i++)if(g->enemies[i].alive){
   float d=dist2(p->pos,g->enemies[i].pos);if(d<best){best=d;bi=i;}
  } p->target=bi;
 } else if(!(b->Buttons&PSP_CTRL_LTRIGGER))p->target=-1;

 if((b->Buttons&PSP_CTRL_SQUARE)&&!p->attackTimer){
  p->attackTimer=(p->combo>=3)?12:9;p->combo++;
  if(p->combo>4)p->combo=1;
  int dmg=18+(p->skills[SKILL_BLADE_1]?6:0)+(p->combo==4?28:0);
  p->animState=2;effects_spawn(p->pos,FX_SLASH,.8f+p->combo*.12f);
  hit_area(g,p->combo==4?3.5f:2.5f,dmg,p->combo==4?20:8);
 }
 if((b->Buttons&PSP_CTRL_TRIANGLE)&&!p->attackTimer){
  p->attackTimer=24;p->combo=4;p->animState=3;effects_spawn(p->pos,FX_SLASH,1.8f);hit_area(g,3.8f,55+(p->skills[SKILL_BLADE_2]?25:0),24);
 }
 if((b->Buttons&PSP_CTRL_CROSS)&&!p->dashTimer)p->dashTimer=16;
 if(b->Buttons&PSP_CTRL_UP)technique(g,0);
 if(b->Buttons&PSP_CTRL_RIGHT)technique(g,1);
 if(b->Buttons&PSP_CTRL_DOWN)technique(g,2);
 if(b->Buttons&PSP_CTRL_CIRCLE)skill_unlock(p);

 int need=100+p->level*100;
 if(p->xp>=need){p->xp-=need;p->level++;p->skillPoints++;p->maxHp+=20;p->hp=p->maxHp;p->maxChakra+=10;}
}
