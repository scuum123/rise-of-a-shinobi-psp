#include "game.h"

void skills_init(Player *p){for(int i=0;i<SKILL_COUNT;i++)p->skills[i]=0;}

void skill_unlock(Player *p){
 if(p->skillPoints<=0)return;
 for(int i=0;i<SKILL_COUNT;i++){
  if(!p->skills[i]){
   if(i==SKILL_BLADE_2 && !p->skills[SKILL_BLADE_1]) continue;
   if(i==SKILL_CHAKRA_2 && !p->skills[SKILL_CHAKRA_1]) continue;
   if(i==SKILL_SHADOW_2 && !p->skills[SKILL_SHADOW_1]) continue;
   p->skills[i]=1;p->skillPoints--;return;
  }
 }
}
