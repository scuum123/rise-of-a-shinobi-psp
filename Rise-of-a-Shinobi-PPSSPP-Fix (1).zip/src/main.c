#include <pspkernel.h>
#include <pspdisplay.h>
#include <pspctrl.h>
#include <pspgu.h>
#include <pspdebug.h>
#include "game.h"

PSP_MODULE_INFO("The Rise of a Shinobi", 0, 1, 0);
PSP_MAIN_THREAD_ATTR(PSP_THREAD_ATTR_USER | PSP_THREAD_ATTR_VFPU);

static int exit_cb(int a,int b,void*c){sceKernelExitGame();return 0;}
static int cb_thread(SceSize args,void*argp){
 int id=sceKernelCreateCallback("Exit Callback",exit_cb,NULL);
 sceKernelRegisterExitCallback(id); sceKernelSleepThreadCB(); return 0;
}
static void callbacks(void){
 int t=sceKernelCreateThread("callback_thread",cb_thread,0x11,0xFA0,0,NULL);
 if(t>=0)sceKernelStartThread(t,0,NULL);
}
int main(void){
 callbacks();
 pspDebugScreenInit();render_init();
 sceCtrlSetSamplingCycle(0);
 sceCtrlSetSamplingMode(PSP_CTRL_MODE_ANALOG);
 GameState g; game_init(&g);
 while(1){
  SceCtrlData p; sceCtrlReadBufferPositive(&p,1);
  if(p.Buttons&PSP_CTRL_HOME) break;
  game_update(&g,&p);
  game_render(&g);
  sceDisplayWaitVblankStart();
  sceGuSwapBuffers();
 }
 sceKernelExitGame(); return 0;
}
