#include <string.h>
#include "game.h"
#include "effects.h"
void player_update(GameState*,const SceCtrlData*);
void enemy_init(GameState*);void enemy_update(GameState*);
void skills_init(Player*);

void game_init(GameState*g){
 effects_init();
 memset(g,0,sizeof(*g));
 g->player.maxHp=g->player.hp=150;
 g->player.maxChakra=g->player.chakra=100;
 g->player.level=1;g->player.target=-1;
 skills_init(&g->player);enemy_init(g);
}
void game_update(GameState*g,const SceCtrlData*p){
 g->frame++;
 uint32_t pressed=p->Buttons&~g->previousButtons;if(pressed&PSP_CTRL_START)g->paused=!g->paused;g->previousButtons=p->Buttons;
 if(g->paused)return;
 player_update(g,p);enemy_update(g);
 effects_update(1.0f/60.0f);
 if(g->player.hp<=0){
  g->player.hp=g->player.maxHp;g->player.chakra=g->player.maxChakra;
  g->player.xp=0;g->wave=1;enemy_init(g);
 }
}
