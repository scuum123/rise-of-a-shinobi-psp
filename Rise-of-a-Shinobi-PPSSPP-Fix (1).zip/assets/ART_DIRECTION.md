# Visual direction

The target is a PSP-era low-poly anime ninja aesthetic:
- compact geometry and strong silhouettes
- cel-shaded-looking flat colors
- exaggerated sword arcs and impact flashes
- original shinobi outfits and facial designs
- compact arenas with destructible-looking props
- no Naruto names, characters, logos, music, or ripped assets

## Character roster planned
1. Kage Ren — player shinobi
2. Ashen Blade — fast rival
3. Iron Mask — armored elite
4. Mist Dancer — ranged assassin
5. Storm Lord — boss

## Techniques
- Gale Crescent: forward cutting wave
- Ember Serpent: explosive flame arc
- Void Step: evasive teleport strike

These are original names/concepts for the prototype.
