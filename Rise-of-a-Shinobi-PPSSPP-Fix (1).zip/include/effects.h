#pragma once
#include "game.h"
typedef enum { FX_SLASH, FX_CHAKRA_RING, FX_SHADOW_BURST, FX_HIT } EffectType;
typedef struct { Vec3 pos; float life,maxLife,scale; int type,active; } Effect;
#define MAX_EFFECTS 48
void effects_init(void);
void effects_spawn(Vec3 p,int type,float scale);
void effects_update(float dt);
void effects_render(void);
