#pragma once
#include <pspctrl.h>
#include <stdint.h>

typedef struct { float x,y,z; } Vec3;

typedef enum {
    SKILL_BLADE_1, SKILL_BLADE_2, SKILL_CHAKRA_1,
    SKILL_CHAKRA_2, SKILL_SHADOW_1, SKILL_SHADOW_2,
    SKILL_COUNT
} SkillId;

typedef struct {
    Vec3 pos;
    float yaw;
    int hp,maxHp;
    int chakra,maxChakra;
    int level,xp,skillPoints;
    int combo,attackTimer,dashTimer,techniqueTimer;
    int invincibleTimer;
    int target;
    int animState;
    float animTime;
    int skills[SKILL_COUNT];
} Player;

typedef struct {
    Vec3 pos;
    int hp,maxHp;
    int alive,elite,stagger;
    int attackCooldown;
    float yaw;
} Enemy;
typedef struct { Vec3 pos; int hp,maxHp; int active,phase,attackTimer,stagger; float yaw,animTime; } Boss;

#define MAX_ENEMIES 28

typedef struct {
    Player player;
    Enemy enemies[MAX_ENEMIES];
    Boss boss;
    int wave,enemiesRemaining;
    int paused;
    uint32_t previousButtons;
    uint32_t frame;
} GameState;

void game_init(GameState*);
void game_update(GameState*,const SceCtrlData*);
void render_init(void);
void game_render(const GameState*);
