# v4 encounter design

## The Veiled Warlord

The boss appears on wave 5 and every fifth wave afterward. Phase 1 advances deliberately and deals 24 damage. Below 50% health, Phase 2 increases movement speed, attacks more often, and deals 35 damage. Defeating the boss awards 500 XP and one skill point.

## Original visual identity

The hero wears indigo, standard enemies crimson, elites bronze, and the boss shifts from deep red-blue to violet in Phase 2. This creates a classic handheld anime-ninja mood without copying a licensed character, costume, emblem, or technique.
