#include "rise_game.h"
#include <math.h>
#include <string.h>

static float clampf(float value, float low, float high) {
    return value < low ? low : (value > high ? high : value);
}

static float distance_sq(RiseVec3 a, RiseVec3 b) {
    float x = a.x - b.x;
    float z = a.z - b.z;
    return x * x + z * z;
}

int rise_game_xp_for_level(int level) {
    return 100 + (level - 1) * 75;
}

static void reset_player(RisePlayer *player) {
    memset(player, 0, sizeof(*player));
    player->max_hp = player->hp = 180;
    player->max_chakra = player->chakra = 100;
    player->level = 1;
    player->xp_next = rise_game_xp_for_level(1);
    player->unlocked[0] = 1;
}

void rise_game_init(RiseGame *game) {
    memset(game, 0, sizeof(*game));
    game->mode = RISE_TITLE;
    reset_player(&game->player);
}

static void spawn_enemy(RiseGame *game, int slot, RiseEnemyType type, float x, float z) {
    RiseEnemy *enemy = &game->enemies[slot];
    int hp = type == RISE_ENEMY_RAIDER ? 55 : type == RISE_ENEMY_ARCHER ? 42 : 110;
    if (type == RISE_ENEMY_BOSS) hp = 650;
    *enemy = (RiseEnemy){{x, 0.0f, z}, 0.0f, type, hp, hp, 1, 20, 0};
}

static void spawn_wave(RiseGame *game) {
    int count = 5 + game->wave * 2;
    int i;
    if (count > 14) count = 14;
    memset(game->enemies, 0, sizeof(game->enemies));
    for (i = 0; i < count; ++i) {
        RiseEnemyType type = (i % 5 == 4) ? RISE_ENEMY_ARCHER : RISE_ENEMY_RAIDER;
        if (game->wave >= 2 && i == count - 1) type = RISE_ENEMY_CAPTAIN;
        spawn_enemy(game, i, type, (float)((i % 5) * 3 - 6), (float)(8 + (i / 5) * 4));
    }
}

void rise_game_start(RiseGame *game) {
    uint8_t unlocked[RISE_TECHNIQUE_COUNT];
    int level = game->player.level;
    int xp = game->player.xp;
    int points = game->player.skill_points;
    memcpy(unlocked, game->player.unlocked, sizeof(unlocked));
    memset(game, 0, sizeof(*game));
    reset_player(&game->player);
    game->player.level = level > 0 ? level : 1;
    game->player.xp = xp;
    game->player.skill_points = points;
    memcpy(game->player.unlocked, unlocked, sizeof(unlocked));
    game->player.xp_next = rise_game_xp_for_level(game->player.level);
    game->mode = RISE_PLAYING;
    game->wave = 1;
    game->objective_total = 24;
    spawn_wave(game);
}

static void grant_xp(RisePlayer *player, int amount) {
    player->xp += amount;
    while (player->xp >= player->xp_next) {
        player->xp -= player->xp_next;
        ++player->level;
        ++player->skill_points;
        player->max_hp += 12;
        player->max_chakra += 8;
        player->hp = player->max_hp;
        player->chakra = player->max_chakra;
        player->xp_next = rise_game_xp_for_level(player->level);
        if (player->level == 2) player->unlocked[1] = 1;
        if (player->level == 4) player->unlocked[2] = 1;
    }
}

static void damage_area(RiseGame *game, float radius, int damage, int stagger) {
    int i;
    float radius_sq = radius * radius;
    for (i = 0; i < RISE_MAX_ENEMIES; ++i) {
        RiseEnemy *enemy = &game->enemies[i];
        if (!enemy->active || distance_sq(game->player.position, enemy->position) > radius_sq) continue;
        enemy->hp -= damage;
        enemy->stagger_timer = stagger;
        if (enemy->hp <= 0) {
            enemy->active = 0;
            ++game->defeated;
            if (enemy->type == RISE_ENEMY_BOSS) game->boss_defeated = 1;
            grant_xp(&game->player, enemy->type == RISE_ENEMY_BOSS ? 500 :
                     enemy->type == RISE_ENEMY_CAPTAIN ? 90 : 35);
        }
    }
}

static void update_player(RiseGame *game, const RiseInput *input) {
    RisePlayer *player = &game->player;
    float length = sqrtf(input->move_x * input->move_x + input->move_z * input->move_z);
    float speed = player->dash_timer > 0 ? 0.28f : 0.105f;
    if (length > 0.12f) {
        float x = input->move_x / (length > 1.0f ? length : 1.0f);
        float z = input->move_z / (length > 1.0f ? length : 1.0f);
        player->position.x = clampf(player->position.x + x * speed, -17.0f, 17.0f);
        player->position.z = clampf(player->position.z + z * speed, -12.0f, 22.0f);
        player->facing = atan2f(x, z);
    }
    if (player->attack_timer > 0) --player->attack_timer;
    if (player->combo_timer > 0) --player->combo_timer; else player->combo_step = 0;
    if (player->dash_timer > 0) --player->dash_timer;
    if (player->invulnerable_timer > 0) --player->invulnerable_timer;
    if ((input->pressed & RISE_INPUT_DASH) && player->dash_timer == 0) {
        player->dash_timer = 13;
        player->invulnerable_timer = 9;
    }
    if ((input->pressed & RISE_INPUT_LIGHT) && player->attack_timer == 0) {
        player->combo_step = player->combo_timer ? player->combo_step + 1 : 1;
        if (player->combo_step > 4) player->combo_step = 1;
        player->combo_timer = 24;
        player->attack_timer = 7;
        damage_area(game, player->combo_step == 4 ? 3.2f : 2.25f,
                    15 + player->level * 2 + (player->combo_step == 4 ? 24 : 0), 7);
    }
    if ((input->pressed & RISE_INPUT_HEAVY) && player->attack_timer == 0) {
        player->attack_timer = 20;
        player->combo_timer = 0;
        damage_area(game, 3.8f, 48 + player->level * 3, 20);
    }
    if (input->pressed & RISE_INPUT_TECH_NEXT) {
        int tries;
        for (tries = 0; tries < RISE_TECHNIQUE_COUNT; ++tries) {
            player->selected_technique = (player->selected_technique + 1) % RISE_TECHNIQUE_COUNT;
            if (player->unlocked[player->selected_technique]) break;
        }
    }
    if (input->pressed & RISE_INPUT_TECHNIQUE) {
        static const int costs[RISE_TECHNIQUE_COUNT] = {20, 32, 48};
        static const float ranges[RISE_TECHNIQUE_COUNT] = {4.5f, 7.0f, 5.5f};
        static const int damage[RISE_TECHNIQUE_COUNT] = {48, 72, 115};
        int technique = player->selected_technique;
        if (player->unlocked[technique] && player->chakra >= costs[technique] && player->attack_timer == 0) {
            player->chakra -= costs[technique];
            player->attack_timer = 28;
            damage_area(game, ranges[technique], damage[technique] + player->level * 4, 25);
        }
    }
    if ((game->frame % 30u) == 0u && player->chakra < player->max_chakra) ++player->chakra;
}

static void update_enemies(RiseGame *game, const RiseInput *input) {
    int i;
    int ai_budget = 8;
    for (i = 0; i < RISE_MAX_ENEMIES; ++i) {
        RiseEnemy *enemy = &game->enemies[i];
        float dx, dz, distance;
        if (!enemy->active) continue;
        if (enemy->stagger_timer > 0) { --enemy->stagger_timer; continue; }
        if (enemy->attack_cooldown > 0) --enemy->attack_cooldown;
        if (ai_budget-- <= 0) continue;
        dx = game->player.position.x - enemy->position.x;
        dz = game->player.position.z - enemy->position.z;
        distance = sqrtf(dx * dx + dz * dz) + 0.001f;
        enemy->facing = atan2f(dx, dz);
        if (distance > (enemy->type == RISE_ENEMY_ARCHER ? 6.5f : 1.8f)) {
            float move = enemy->type == RISE_ENEMY_BOSS ? 0.065f : 0.042f;
            enemy->position.x += dx / distance * move;
            enemy->position.z += dz / distance * move;
        } else if (enemy->attack_cooldown == 0) {
            int guarding = (input->held & RISE_INPUT_GUARD) != 0;
            int damage = enemy->type == RISE_ENEMY_BOSS ? 28 : enemy->type == RISE_ENEMY_CAPTAIN ? 16 : 8;
            if (guarding) damage /= 3;
            if (game->player.invulnerable_timer == 0) game->player.hp -= damage;
            enemy->attack_cooldown = enemy->type == RISE_ENEMY_BOSS ? 42 : 70;
        }
    }
}

int rise_game_active_enemies(const RiseGame *game) {
    int i, total = 0;
    for (i = 0; i < RISE_MAX_ENEMIES; ++i) total += game->enemies[i].active != 0;
    return total;
}

void rise_game_update(RiseGame *game, const RiseInput *input) {
    if (game->mode == RISE_TITLE) {
        if (input->pressed & RISE_INPUT_CONFIRM) rise_game_start(game);
        return;
    }
    if (input->pressed & RISE_INPUT_PAUSE) {
        game->mode = game->mode == RISE_PAUSED ? RISE_PLAYING : RISE_PAUSED;
        return;
    }
    if (game->mode != RISE_PLAYING) return;
    ++game->frame;
    update_player(game, input);
    update_enemies(game, input);
    if (game->player.hp <= 0) { game->mode = RISE_DEFEAT; return; }
    if (rise_game_active_enemies(game) == 0) {
        if (game->defeated >= game->objective_total && !game->boss_spawned) {
            spawn_enemy(game, 0, RISE_ENEMY_BOSS, 0.0f, 14.0f);
            game->boss_spawned = 1;
        } else if (game->boss_defeated) {
            game->mode = RISE_VICTORY;
        } else {
            ++game->wave;
            spawn_wave(game);
        }
    }
}
