#include <pspkernel.h>
#include <pspctrl.h>
#include <pspdisplay.h>
#include <pspgu.h>
#include "rise_game.h"
#include "rise_render.h"

PSP_MODULE_INFO("The Rise of a Shinobi", PSP_MODULE_USER, 1, 0);
PSP_MAIN_THREAD_ATTR(PSP_THREAD_ATTR_USER | PSP_THREAD_ATTR_VFPU);
PSP_HEAP_SIZE_KB(-1024);

static int exit_callback(int arg1, int arg2, void *common) {
    (void)arg1; (void)arg2; (void)common;
    sceKernelExitGame();
    return 0;
}

static int callback_thread(SceSize args, void *argp) {
    int callback;
    (void)args; (void)argp;
    callback = sceKernelCreateCallback("Exit Callback", exit_callback, 0);
    sceKernelRegisterExitCallback(callback);
    sceKernelSleepThreadCB();
    return 0;
}

static void setup_callbacks(void) {
    int thread = sceKernelCreateThread("callback_thread", callback_thread, 0x11, 0xFA0, 0, 0);
    if (thread >= 0) sceKernelStartThread(thread, 0, 0);
}

static RiseInput map_input(const SceCtrlData *pad, uint32_t previous) {
    RiseInput input = {0};
    uint32_t buttons = pad->Buttons;
    input.move_x = ((float)pad->Lx - 128.0f) / 127.0f;
    input.move_z = -((float)pad->Ly - 128.0f) / 127.0f;
    if (buttons & PSP_CTRL_SQUARE) input.held |= RISE_INPUT_LIGHT;
    if (buttons & PSP_CTRL_TRIANGLE) input.held |= RISE_INPUT_HEAVY;
    if (buttons & PSP_CTRL_CROSS) input.held |= RISE_INPUT_DASH | RISE_INPUT_CONFIRM;
    if (buttons & PSP_CTRL_CIRCLE) input.held |= RISE_INPUT_TECHNIQUE;
    if (buttons & PSP_CTRL_RTRIGGER) input.held |= RISE_INPUT_GUARD;
    if (buttons & PSP_CTRL_START) input.held |= RISE_INPUT_PAUSE;
    if (buttons & PSP_CTRL_RIGHT) input.held |= RISE_INPUT_TECH_NEXT;
    input.pressed = input.held & ~previous;
    return input;
}

int main(void) {
    RiseGame game;
    uint32_t previous = 0;
    setup_callbacks();
    sceCtrlSetSamplingCycle(0);
    sceCtrlSetSamplingMode(PSP_CTRL_MODE_ANALOG);
    rise_game_init(&game);
    rise_render_init();
    for (;;) {
        SceCtrlData pad;
        RiseInput input;
        sceCtrlReadBufferPositive(&pad, 1);
        input = map_input(&pad, previous);
        previous = input.held;
        rise_game_update(&game, &input);
        rise_render_frame(&game);
        sceDisplayWaitVblankStart();
        sceGuSwapBuffers();
    }
    rise_render_shutdown();
    sceKernelExitGame();
    return 0;
}
