#include <pspgu.h>
#include <pspgum.h>
#include <pspdisplay.h>
#include <pspkernel.h>
#include <math.h>
#include <string.h>
#include "rise_render.h"

typedef struct { unsigned int color; float x, y, z; } Vertex3D;
typedef struct { unsigned int color; short x, y, z; } Vertex2D;

static unsigned int __attribute__((aligned(16))) command_list[262144];

static const unsigned char font5x7[36][5] = {
    {0x7E,0x11,0x11,0x11,0x7E},{0x7F,0x49,0x49,0x49,0x36},
    {0x3E,0x41,0x41,0x41,0x22},{0x7F,0x41,0x41,0x22,0x1C},
    {0x7F,0x49,0x49,0x49,0x41},{0x7F,0x09,0x09,0x09,0x01},
    {0x3E,0x41,0x49,0x49,0x7A},{0x7F,0x08,0x08,0x08,0x7F},
    {0x00,0x41,0x7F,0x41,0x00},{0x20,0x40,0x41,0x3F,0x01},
    {0x7F,0x08,0x14,0x22,0x41},{0x7F,0x40,0x40,0x40,0x40},
    {0x7F,0x02,0x0C,0x02,0x7F},{0x7F,0x04,0x08,0x10,0x7F},
    {0x3E,0x41,0x41,0x41,0x3E},{0x7F,0x09,0x09,0x09,0x06},
    {0x3E,0x41,0x51,0x21,0x5E},{0x7F,0x09,0x19,0x29,0x46},
    {0x46,0x49,0x49,0x49,0x31},{0x01,0x01,0x7F,0x01,0x01},
    {0x3F,0x40,0x40,0x40,0x3F},{0x1F,0x20,0x40,0x20,0x1F},
    {0x3F,0x40,0x38,0x40,0x3F},{0x63,0x14,0x08,0x14,0x63},
    {0x07,0x08,0x70,0x08,0x07},{0x61,0x51,0x49,0x45,0x43},
    {0x3E,0x51,0x49,0x45,0x3E},{0x00,0x42,0x7F,0x40,0x00},
    {0x42,0x61,0x51,0x49,0x46},{0x21,0x41,0x45,0x4B,0x31},
    {0x18,0x14,0x12,0x7F,0x10},{0x27,0x45,0x45,0x45,0x39},
    {0x3C,0x4A,0x49,0x49,0x30},{0x01,0x71,0x09,0x05,0x03},
    {0x36,0x49,0x49,0x49,0x36},{0x06,0x49,0x49,0x29,0x1E}
};

static const float cube_positions[8][3] = {
    {-1,-1,-1},{1,-1,-1},{1,1,-1},{-1,1,-1},
    {-1,-1, 1},{1,-1, 1},{1,1, 1},{-1,1, 1}
};
static const unsigned short cube_indices[36] = {
    0,1,2,0,2,3, 4,6,5,4,7,6, 0,4,5,0,5,1,
    3,2,6,3,6,7, 0,3,7,0,7,4, 1,5,6,1,6,2
};

static void cube(float x, float y, float z, float sx, float sy, float sz, unsigned int color) {
    Vertex3D *vertices = (Vertex3D*)sceGuGetMemory(sizeof(Vertex3D) * 8);
    unsigned short *indices = (unsigned short*)sceGuGetMemory(sizeof(cube_indices));
    ScePspFVector3 position = {x,y,z};
    ScePspFVector3 scale = {sx,sy,sz};
    int i;
    for (i = 0; i < 8; ++i) {
        vertices[i].color = color;
        vertices[i].x = cube_positions[i][0];
        vertices[i].y = cube_positions[i][1];
        vertices[i].z = cube_positions[i][2];
    }
    memcpy(indices, cube_indices, sizeof(cube_indices));
    sceGumPushMatrix();
    sceGumTranslate(&position);
    sceGumScale(&scale);
    sceGumDrawArray(GU_TRIANGLES,
        GU_INDEX_16BIT | GU_COLOR_8888 | GU_VERTEX_32BITF | GU_TRANSFORM_3D,
        36, indices, vertices);
    sceGumPopMatrix();
}

static void body_part(float x,float y,float z,float sx,float sy,float sz,float rotation,unsigned int color) {
    ScePspFVector3 position = {x,y,z};
    sceGumPushMatrix();
    sceGumTranslate(&position);
    sceGumRotateZ(rotation);
    cube(0,0,0,sx,sy,sz,color);
    sceGumPopMatrix();
}

static void shinobi(RiseVec3 position, float facing, unsigned int cloth, int boss, int attacking, float phase) {
    ScePspFVector3 translation = {position.x,position.y,position.z};
    ScePspFVector3 scale = {boss ? 1.45f : 1.0f,boss ? 1.45f : 1.0f,boss ? 1.45f : 1.0f};
    float stride = sinf(phase) * 0.3f;
    float slash = attacking ? sinf(phase * 2.0f) * 1.15f : 0.0f;
    sceGumPushMatrix();
    sceGumTranslate(&translation);
    sceGumRotateY(facing);
    sceGumScale(&scale);
    body_part(0,1.18f,0,.43f,.58f,.27f,0,cloth);
    body_part(0,1.93f,0,.31f,.31f,.31f,0,0xFFB77C5B);
    body_part(0,2.02f,.30f,.37f,.08f,.04f,0,0xFF26304A);
    body_part(-.22f,.42f,0,.16f,.48f,.18f,stride,0xFF202634);
    body_part(.22f,.42f,0,.16f,.48f,.18f,-stride,0xFF202634);
    body_part(-.55f,1.30f,0,.13f,.48f,.14f,-stride,cloth);
    body_part(.55f,1.30f,0,.13f,.48f,.14f,stride-slash,cloth);
    body_part(.75f,1.08f,0,.045f,.65f,.055f,-.55f-slash,0xFFD6E5F2);
    sceGumPopMatrix();
}

static void draw_world(const RiseGame *game) {
    int i;
    cube(0,-.45f,5,18,.40f,18,0xFF394B3B);
    cube(-18,1.2f,5,.35f,1.6f,18,0xFF35404B);
    cube(18,1.2f,5,.35f,1.6f,18,0xFF35404B);
    cube(0,1.2f,23,18,1.6f,.35f,0xFF35404B);
    for (i = 0; i < 9; ++i) {
        float side = (i & 1) ? 1.0f : -1.0f;
        cube(side * (10.0f + (i % 3) * 2.2f),1.6f,(float)(i * 4 - 8),.65f,1.7f,.65f,0xFF45543A);
    }
    shinobi(game->player.position, game->player.facing, 0xFF294FA8, 0,
            game->player.attack_timer > 0, game->frame * .14f);
    for (i = 0; i < RISE_MAX_ENEMIES; ++i) {
        const RiseEnemy *enemy = &game->enemies[i];
        unsigned int color;
        if (!enemy->active) continue;
        color = enemy->type == RISE_ENEMY_ARCHER ? 0xFF80511F :
                enemy->type == RISE_ENEMY_CAPTAIN ? 0xFF7C245E :
                enemy->type == RISE_ENEMY_BOSS ? 0xFF351B65 : 0xFF8F2930;
        if (enemy->stagger_timer > 0) color = 0xFFE7E7FF;
        shinobi(enemy->position, enemy->facing, color,
                enemy->type == RISE_ENEMY_BOSS, enemy->attack_cooldown > 60,
                game->frame * .11f + i);
    }
}

static void rect(int x, int y, int width, int height, unsigned int color) {
    Vertex2D *v = (Vertex2D*)sceGuGetMemory(sizeof(Vertex2D) * 2);
    v[0] = (Vertex2D){color,(short)x,(short)y,0};
    v[1] = (Vertex2D){color,(short)(x+width),(short)(y+height),0};
    sceGuDrawArray(GU_SPRITES, GU_COLOR_8888 | GU_VERTEX_16BIT | GU_TRANSFORM_2D, 2, 0, v);
}

static void text(int x, int y, const char *value, int scale, unsigned int color) {
    while (*value) {
        int glyph = -1;
        int column, row;
        char c = *value++;
        if (c >= 'A' && c <= 'Z') glyph = c - 'A';
        else if (c >= '0' && c <= '9') glyph = 26 + c - '0';
        if (glyph >= 0) {
            for (column = 0; column < 5; ++column)
                for (row = 0; row < 7; ++row)
                    if (font5x7[glyph][column] & (1u << row))
                        rect(x + column * scale, y + row * scale, scale, scale, color);
        }
        x += 6 * scale;
    }
}

static void number_text(int x, int y, int number, int scale, unsigned int color) {
    char buffer[12];
    int end = 11;
    buffer[end] = 0;
    do { buffer[--end] = (char)('0' + number % 10); number /= 10; } while (number && end > 0);
    text(x,y,&buffer[end],scale,color);
}

static void hud(const RiseGame *game) {
    int hp_width = 150 * game->player.hp / game->player.max_hp;
    int chakra_width = 120 * game->player.chakra / game->player.max_chakra;
    int xp_width = 100 * game->player.xp / game->player.xp_next;
    sceGuDisable(GU_DEPTH_TEST);
    sceGuEnable(GU_BLEND);
    sceGuBlendFunc(GU_ADD, GU_SRC_ALPHA, GU_ONE_MINUS_SRC_ALPHA, 0, 0);
    rect(14,12,158,14,0xB0000000); rect(18,16,hp_width,6,0xFF3245E8);
    rect(14,30,128,12,0xB0000000); rect(18,34,chakra_width,4,0xFFE8A832);
    rect(14,46,108,10,0xB0000000); rect(18,49,xp_width,3,0xFF45D878);
    rect(382,14,80,12,0xB0000000);
    rect(386,18,72 * rise_game_active_enemies(game) / RISE_MAX_ENEMIES,4,0xFF5260DD);
    text(14,61,"LV",1,0xFFFFFFFF); number_text(30,61,game->player.level,1,0xFFFFFFFF);
    text(382,31,"WAVE",1,0xFFFFFFFF); number_text(416,31,game->wave,1,0xFFFFFFFF);
    if (game->mode == RISE_TITLE) {
        rect(80,55,320,155,0xD0181420);
        rect(115,82,250,50,0xFF27375D);
        rect(170,165,140,22,0xFF315E9A);
        text(132,91,"THE RISE OF A",2,0xFFFFFFFF);
        text(150,111,"SHINOBI",2,0xFFFFD56A);
        text(192,171,"PRESS X",1,0xFFFFFFFF);
    } else if (game->mode == RISE_PAUSED) {
        rect(125,75,230,120,0xD0181420);
        text(190,103,"PAUSED",2,0xFFFFFFFF);
        text(169,151,"PRESS START",1,0xFFBFD5FF);
    } else if (game->mode == RISE_VICTORY) {
        rect(95,70,290,130,0xD0193827);
        text(171,100,"VICTORY",2,0xFFFFD56A);
        text(171,145,"MISSION CLEAR",1,0xFFFFFFFF);
    } else if (game->mode == RISE_DEFEAT) {
        rect(95,70,290,130,0xD03C1720);
        text(181,100,"DEFEAT",2,0xFFFFA0A0);
        text(171,145,"TRAIN AGAIN",1,0xFFFFFFFF);
    }
    sceGuDisable(GU_BLEND);
}

void rise_render_init(void) {
    sceGuInit();
    sceGuStart(GU_DIRECT, command_list);
    sceGuDrawBuffer(GU_PSM_8888, (void*)0, 512);
    sceGuDispBuffer(480, 272, (void*)0x88000, 512);
    sceGuDepthBuffer((void*)0x110000, 512);
    sceGuOffset(2048 - 240, 2048 - 136);
    sceGuViewport(2048, 2048, 480, 272);
    sceGuDepthRange(65535, 0);
    sceGuScissor(0, 0, 480, 272);
    sceGuEnable(GU_SCISSOR_TEST);
    sceGuDepthFunc(GU_GEQUAL);
    sceGuFrontFace(GU_CW);
    sceGuShadeModel(GU_FLAT);
    sceGuFinish();
    sceGuSync(0,0);
    sceDisplayWaitVblankStart();
    sceGuDisplay(GU_TRUE);
}

void rise_render_frame(const RiseGame *game) {
    ScePspFVector3 eye = {game->player.position.x, game->player.position.y + 6.2f, game->player.position.z - 10.0f};
    ScePspFVector3 center = {game->player.position.x, game->player.position.y + 1.0f, game->player.position.z + 2.2f};
    ScePspFVector3 up = {0,1,0};
    sceGuStart(GU_DIRECT, command_list);
    sceGuClearColor(0xFF241B28);
    sceGuClearDepth(0);
    sceGuClear(GU_COLOR_BUFFER_BIT | GU_DEPTH_BUFFER_BIT);
    sceGuEnable(GU_DEPTH_TEST);
    sceGumMatrixMode(GU_PROJECTION);
    sceGumLoadIdentity();
    sceGumPerspective(52.0f, 480.0f/272.0f, 0.5f, 100.0f);
    sceGumMatrixMode(GU_VIEW);
    sceGumLoadIdentity();
    sceGumLookAt(&eye,&center,&up);
    sceGumMatrixMode(GU_MODEL);
    sceGumLoadIdentity();
    if (game->mode != RISE_TITLE) draw_world(game);
    hud(game);
    sceKernelDcacheWritebackAll();
    sceGuFinish();
    sceGuSync(0,0);
}

void rise_render_shutdown(void) {
    sceGuTerm();
}
