# The Rise of a Shinobi

An original 3D anime-ninja hack-and-slash for PSP and PPSSPP.

## Current milestone

The first vertical-slice foundation includes a title screen, third-person arena,
crowd combat, four enemy roles, combo attacks, techniques, leveling, a boss,
pause, victory, defeat, and a compact PSP-focused renderer.

## Build

Install the PSPDEV toolchain and run `make`, or push this source tree to GitHub
with Actions enabled. The included workflow creates a PPSSPP-ready artifact.

## Install

Copy `PSP/GAME/RiseShinobi` to the emulated or physical PSP memory stick, then
launch The Rise of a Shinobi from the game list.

## Controls

- Analog: move
- Square: light combo
- Triangle: heavy strike
- Cross: dash / confirm
- Circle: selected technique
- Right: cycle technique
- R: guard
- Start: pause
