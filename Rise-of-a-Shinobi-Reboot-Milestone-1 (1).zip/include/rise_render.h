#ifndef RISE_RENDER_H
#define RISE_RENDER_H

#include "rise_game.h"

void rise_render_init(void);
void rise_render_frame(const RiseGame *game);
void rise_render_shutdown(void);

#endif
