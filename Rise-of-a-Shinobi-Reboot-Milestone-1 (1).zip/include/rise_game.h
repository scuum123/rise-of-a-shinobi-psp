#ifndef RISE_GAME_H
#define RISE_GAME_H

#include <stdint.h>

#define RISE_MAX_ENEMIES 18
#define RISE_TECHNIQUE_COUNT 3

typedef struct { float x, y, z; } RiseVec3;

typedef enum {
    RISE_TITLE,
    RISE_PLAYING,
    RISE_PAUSED,
    RISE_VICTORY,
    RISE_DEFEAT
} RiseMode;

typedef enum {
    RISE_ENEMY_RAIDER,
    RISE_ENEMY_ARCHER,
    RISE_ENEMY_CAPTAIN,
    RISE_ENEMY_BOSS
} RiseEnemyType;

enum {
    RISE_INPUT_LIGHT       = 1u << 0,
    RISE_INPUT_HEAVY       = 1u << 1,
    RISE_INPUT_DASH        = 1u << 2,
    RISE_INPUT_TECHNIQUE   = 1u << 3,
    RISE_INPUT_GUARD       = 1u << 4,
    RISE_INPUT_PAUSE       = 1u << 5,
    RISE_INPUT_CONFIRM     = 1u << 6,
    RISE_INPUT_TECH_NEXT   = 1u << 7
};

typedef struct {
    float move_x;
    float move_z;
    uint32_t held;
    uint32_t pressed;
} RiseInput;

typedef struct {
    RiseVec3 position;
    float facing;
    int hp, max_hp;
    int chakra, max_chakra;
    int level, xp, xp_next;
    int skill_points;
    int combo_step, combo_timer;
    int attack_timer, dash_timer, invulnerable_timer;
    int selected_technique;
    uint8_t unlocked[RISE_TECHNIQUE_COUNT];
} RisePlayer;

typedef struct {
    RiseVec3 position;
    float facing;
    RiseEnemyType type;
    int hp, max_hp;
    int active;
    int attack_cooldown;
    int stagger_timer;
} RiseEnemy;

typedef struct {
    RiseMode mode;
    RisePlayer player;
    RiseEnemy enemies[RISE_MAX_ENEMIES];
    uint32_t frame;
    int wave;
    int defeated;
    int objective_total;
    int boss_spawned;
    int boss_defeated;
} RiseGame;

void rise_game_init(RiseGame *game);
void rise_game_start(RiseGame *game);
void rise_game_update(RiseGame *game, const RiseInput *input);
int rise_game_active_enemies(const RiseGame *game);
int rise_game_xp_for_level(int level);

#endif
