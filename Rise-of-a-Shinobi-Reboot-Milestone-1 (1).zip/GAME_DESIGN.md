# The Rise of a Shinobi

An original third-person anime-ninja hack-and-slash for PSP and PPSSPP.

## First playable release

- One battlefield: Cedar Pass
- One player character: Ren, an apprentice of the Storm Heron clan
- Three enemy roles: raider, archer, and captain
- One boss: Kagehane, the Ash Ronin
- Light combo, heavy finisher, dash, guard, lock-on, and three techniques
- XP, levels, technique points, and persistent save data
- Title, pause, victory, defeat, and results screens

## Controls

| Input | Action |
| --- | --- |
| Analog | Move |
| D-pad | Rotate camera / select technique |
| Square | Light attack |
| Triangle | Heavy attack |
| Cross | Dash / confirm |
| Circle | Use selected technique |
| L | Lock on / recenter camera |
| R | Guard |
| Start | Pause |

## PSP performance budget

- 480 x 272 at a 30 FPS target
- Up to 18 active enemies, with 8 using full AI per frame
- Low-poly characters with cel-shaded color ramps
- 256 x 256 or smaller indexed textures
- Short ADPCM sound effects and streamed music
- Fixed-size gameplay pools; no allocation during combat

## Originality

The game uses an original cast, clans, symbols, story, techniques, music, and art.
Its broad visual language is early-2000s cel-shaded ninja anime, without using
copyrighted Naruto characters or assets.
