#include "rise_game.h"
#include <assert.h>
#include <stdio.h>

static RiseInput press(uint32_t button) {
    RiseInput input = {0};
    input.pressed = button;
    input.held = button;
    return input;
}

int main(void) {
    RiseGame game;
    RiseInput input;
    int old_chakra;
    rise_game_init(&game);
    assert(game.mode == RISE_TITLE);
    input = press(RISE_INPUT_CONFIRM);
    rise_game_update(&game, &input);
    assert(game.mode == RISE_PLAYING);
    assert(rise_game_active_enemies(&game) == 7);

    game.enemies[0].position = game.player.position;
    game.enemies[0].hp = 1;
    input = press(RISE_INPUT_LIGHT);
    rise_game_update(&game, &input);
    assert(!game.enemies[0].active);
    assert(game.player.xp > 0);

    game.player.attack_timer = 0;
    old_chakra = game.player.chakra;
    input = press(RISE_INPUT_TECHNIQUE);
    rise_game_update(&game, &input);
    assert(game.player.chakra < old_chakra);

    game.player.xp = game.player.xp_next - 1;
    game.enemies[1].position = game.player.position;
    game.enemies[1].hp = 1;
    game.player.attack_timer = 0;
    input = press(RISE_INPUT_HEAVY);
    rise_game_update(&game, &input);
    assert(game.player.level == 2);
    assert(game.player.unlocked[1]);

    puts("rise_game tests passed");
    return 0;
}
